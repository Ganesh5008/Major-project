import os
import time
import datetime
import pyttsx3
import speech_recognition as sr
import webbrowser
import smtplib
import requests
import psutil
from tkinter import Tk, simpledialog
import subprocess
from PIL import ImageGrab
import pyautogui
import json
import pygame
from  PyDictionary import PyDictionary
import sqlite3

# Initialize text-to-speech engine
engine = pyttsx3.init()
engine.setProperty("rate", 150)

def speak(text):
    engine.say(text)
    engine.runAndWait()

def take_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak("Listening...")
        try:
            audio = recognizer.listen(source, timeout=5)
            return recognizer.recognize_google(audio).lower()
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that.")
            return None
        except sr.RequestError:
            speak("Error with the recognition service.")
            return None

# Media Control

# Initialize Pygame mixer
pygame.mixer.init()

# Global variables for song list and current song index
songs_folder = r"C:\Users\vutla\Music\re"  # Replace with your songs folder path
song_list = [f for f in os.listdir(songs_folder) if f.endswith(('.mp3', '.wav'))]
current_song_index = 0

def play_song(index):
    """Play the song at the given index."""
    global current_song_index
    if 0 <= index < len(song_list):
        current_song_index = index
        song_path = os.path.join(songs_folder, song_list[current_song_index])
        pygame.mixer.music.load(song_path)
        pygame.mixer.music.play()
        speak(f"Playing {song_list[current_song_index]}")
    else:
        speak("No songs available to play.")

def control_media(command):
    """Control media playback."""
    global current_song_index
    if "play song" in command:
        play_song(current_song_index)
    elif "pause" in command:
        pygame.mixer.music.pause()
        speak("Music paused.")
    elif "resume" in command:
        pygame.mixer.music.unpause()
        speak("Music resumed.")
    elif "next" in command:
        current_song_index = (current_song_index + 1) % len(song_list)
        play_song(current_song_index)
    elif "previous" in command:
        current_song_index = (current_song_index - 1) % len(song_list)
        play_song(current_song_index)
    elif "volume up" in command:
        volume = pygame.mixer.music.get_volume()
        pygame.mixer.music.set_volume(min(volume + 0.1, 1.0))
        speak("Volume increased.")
    elif "volume down" in command:
        volume = pygame.mixer.music.get_volume()
        pygame.mixer.music.set_volume(max(volume - 0.1, 0.0))
        speak("Volume decreased.")
    elif "stop" in command:
        pygame.mixer.music.stop()
        speak("Music stopped.")

# Reminders

def set_reminder():
    speak("What should I remind you about?")
    reminder = take_command()
    if reminder:
        conn = sqlite3.connect('bruce.db')
        cursor = conn.cursor()
        reminder_time = time.time() + 30 * 60  # 30 minutes from now
        cursor.execute('INSERT INTO reminders (text, time) VALUES (?, ?)', (reminder, reminder_time))
        conn.commit()
        conn.close()
        speak("Reminder set for 30 minutes.")

def check_reminders():
    conn = sqlite3.connect('bruce.db')
    cursor = conn.cursor()
    current_time = time.time()
    cursor.execute('SELECT id, text FROM reminders WHERE time <= ?', (current_time,))
    reminders_to_notify = cursor.fetchall()
    for reminder_id, reminder_text in reminders_to_notify:
        speak(f"Reminder: {reminder_text}")
        cursor.execute('DELETE FROM reminders WHERE id = ?', (reminder_id,))
    conn.commit()
    conn.close()

# Notepad Integration
def open_notepad():
    os.system("notepad")

def save_note():
    speak("What should I save in the note?")
    content = take_command()
    with open("note.txt", "a") as file:
        file.write(f"{datetime.datetime.now()} - {content}\n")
    speak("Note saved.")

# Task List Management

def add_task():
    speak("What task would you like to add?")
    task = take_command()
    if task:
        conn = sqlite3.connect('bruce.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO tasks (description) VALUES (?)', (task,))
        conn.commit()
        conn.close()
        speak(f"Task added: {task}")

def show_tasks():
    conn = sqlite3.connect('bruce.db')
    cursor = conn.cursor()
    cursor.execute('SELECT id, description FROM tasks')
    tasks = cursor.fetchall()
    conn.close()
    if tasks:
        for task_id, task_desc in tasks:
            speak(f"Task {task_id}: {task_desc}")
    else:
        speak("No tasks found.")

def clear_tasks():
    conn = sqlite3.connect('bruce.db')
    cursor = conn.cursor()
    cursor.execute('DELETE FROM tasks')
    conn.commit()
    conn.close()
    speak("All tasks cleared.")

# Weather Updates
def get_weather():
    try:
        speak("Opening weather information for Hyderabad.")
        # Opens the weather page for Hyderabad in the default browser
        webbrowser.open("https://www.weather.com/weather/today/l/17.38,78.47")
    except Exception as e:
        speak(f"An error occurred while retrieving the weather. {str(e)}")

# Quick Dictionary
def get_meaning():
    speak("Which word would you like to look up?")
    word = take_command()
    try:
        dictionary = PyDictionary()
        meaning = dictionary.meaning(word)
        if meaning:
            for key, value in meaning.items():
                speak(f"{key}: {', '.join(value)}")
        else:
            speak("I couldn't find the meaning.")
    except ImportError:
        speak("Dictionary feature requires PyDictionary module. Please install it.")

# Quick Access Commands
quick_access = {
    "chrome": "C:/Program Files/Google/Chrome/Application/chrome.exe",
    "notepad": "notepad",
}

def open_quick_access():
    speak("Which application would you like to open?")
    app = take_command()
    if app in quick_access:
        os.startfile(quick_access[app])
        speak(f"Opening {app}.")
    else:
        speak("Application not found in quick access commands.")

# Customizable Shortcuts

def add_shortcut():
    speak("What is the shortcut name?")
    name = take_command()
    if name:
        speak("Please paste the path for this shortcut.")
        path = input("Enter the path: ")  # User pastes the path here
        conn = sqlite3.connect('bruce.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO shortcuts (name, path) VALUES (?, ?)', (name, path))
        conn.commit()
        conn.close()
        speak("Shortcut added.")

def execute_shortcut():
    speak("Which shortcut would you like to execute?")
    name = take_command()
    if name:
        conn = sqlite3.connect('bruce.db')
        cursor = conn.cursor()
        cursor.execute('SELECT path FROM shortcuts WHERE name = ?', (name,))
        result = cursor.fetchone()
        conn.close()
        if result:
            os.startfile(result[0])
            speak(f"Executing shortcut {name}.")
        else:
            speak("Shortcut not found.")

# Initialize shortcuts from file
if os.path.exists("shortcuts.json"):
    with open("shortcuts.json", "r") as file:
        shortcuts = json.load(file)

# Features Implementation
def open_file():
    speak("What is the name of the file you'd like to open?")
    file_name = take_command()
    if file_name:
        file_path = rf"C:\Users\vutla\OneDrive\Documents\{file_name}.txt" 
        if os.path.exists(file_path):
            os.startfile(file_path)
            speak(f"Opening {file_name}")
        else:
            speak("Sorry, I couldn't find that file.")
 
def take_screenshot():
    try:
        screenshot = ImageGrab.grab()
        save_path = r"C:\Users\vutla\OneDrive\Pictures\screenshot.png"
        screenshot.save(save_path)
        speak(f"Screenshot taken and saved at {save_path}.")
    except Exception as e:
        speak(f"Failed to take a screenshot. Error: {str(e)}")

def show_date_time():
    now = datetime.datetime.now()
    speak(f"The current date is {now.strftime('%Y-%m-%d')} and the time is {now.strftime('%H:%M:%S')}.")

def web_search():
    speak("What should I search for?")
    query = take_command()
    if query:
        webbrowser.open(f"https://www.google.com/search?q={query}")
        speak(f"Searching for {query}")

def send_email():
    speak("To whom should I send the email?")
    recipient = simpledialog.askstring("Email", "Enter recipient email:")
    speak("What should I say?")
    content = take_command()
    if recipient and content:
        try:
            server = smtplib.SMTP("smtp.gmail.com", 587)
            server.starttls()
            server.login("vaishnavtechnologiesassistance@gmail.com", "mzzhrokesnjyzgvc")
            server.sendmail("vaishnavtechnologiesassistance@gmail.com", recipient, content)
            server.quit()
            speak("Email sent successfully.")
        except Exception as e:
            speak(f"Failed to send email. {str(e)}")

def system_info():
    battery = psutil.sensors_battery()
    speak(f"Your system has {battery.percent} percent battery remaining.")

def shut_down_pc():
    speak("Are you sure you want to shut down the PC?")
    confirmation = take_command()
    if "yes" in confirmation:
        os.system("shutdown /s /t 1")
        speak("Shutting down the PC.")

# Main Menu
def basic_mode():
    while True:
        speak("How can I assist you?")
        command = take_command()
        if command:
            if "open file" in command:
                open_file()
            elif "screenshot" in command:
                take_screenshot()
            elif "time" in command or "date" in command:
                show_date_time()
            elif "search" in command:
                web_search()
            elif "email" in command:
                send_email()
            elif "battery" in command or "system info" in command:
                system_info()
            elif "shut down" in command:
                shut_down_pc()
                break
            elif "add reminder" in command:
                set_reminder()
            elif "check reminders" in command:
                check_reminders()
            elif "add task" in command:
                add_task()
            elif "show task" in command:
                show_tasks()
            elif "clear task" in command:
                clear_tasks()
            elif "notepad" in command:
                open_notepad()
            elif "save note" in command:
                save_note()
            elif "get weather" in command:
                get_weather()
            elif "define" in command or "dictionary" in command:
                get_meaning()
            elif "open quick access" in command:
                open_quick_access()
            elif "add shortcut" in command:
                add_shortcut()
            elif "execute shortcut" in command:
                execute_shortcut()
            elif "play Song" in command or "stop" in command or "next" in command or "previous" in command or "volume up" in command or "volume down" in command or "pause" in command:
                control_media(command)    
            elif "exit" in command or "quit" in command:
                speak("Exiting Basic Mode. Goodbye!")
                break
            else:
                speak("Sorry, I didn't understand that.")

if __name__ == "__main__":
    speak("Welcome to Bruce. You are in Basic Mode.")
    basic_mode()
