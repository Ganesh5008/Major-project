import sqlite3
import pyttsx3
import speech_recognition as sr
import openai
from datetime import datetime

# Initialize Text-to-Speech
engine = pyttsx3.init()

def speak(text):
    engine.say(text)
    engine.runAndWait()

# Advanced Speech Recognition
def take_advanced_command():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        speak("Listening...")
        recognizer.adjust_for_ambient_noise(source)
        try:
            audio = recognizer.listen(source, timeout=10)
            command = recognizer.recognize_google(audio)
            return command.lower()
        except sr.UnknownValueError:
            speak("Sorry, I didn't catch that.")
        except sr.RequestError:
            speak("There seems to be an issue with the recognition service.")
        return ""

# Database Operations
def get_database_connection():
    return sqlite3.connect('bruce.db')

# Sync Tasks, Reminders, and Notes
def sync_basic_advanced():
    conn = get_database_connection()
    cursor = conn.cursor()
    
    speak("Syncing tasks, reminders, and notes between modes.")
    cursor.execute("SELECT * FROM tasks")
    tasks = cursor.fetchall()
    cursor.execute("SELECT * FROM reminders")
    reminders = cursor.fetchall()
    
    if tasks or reminders:
        speak("Here are the synced items:")
        for task in tasks:
            speak(f"Task: {task[1]}")
        for reminder in reminders:
            speak(f"Reminder: {reminder[1]} at {reminder[2]}")
    else:
        speak("No tasks or reminders to sync.")
    
    conn.close()

# NLP with ChatGPT
def chat_with_gpt(prompt):
    openai.api_key = openai.api_key = "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"  # Replace with your API key

    try:
        # Use the correct method for completion
        response = openai.Completion.create(
            engine="gpt-3.5-turbo",  # Replace with "gpt-4" or correct engine name
            prompt=prompt,
            max_tokens=150,  # Adjust token limit as needed
            temperature=0.7,
            n=1,
            stop=None
        )
        reply = response.choices[0].text.strip()
        print("ChatGPT:", reply)  # Debugging output
        speak(reply)  # Speak the response
        return reply
    except Exception as e:  # Generic exception handling for debugging
        print("Error:", e)
        speak("There was an error connecting to OpenAI.")
        return "Error occurred while processing the request."

#     openai.api_key = "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"    # Replace with your actual API key

# Advanced Mode Features
def advanced_mode():
    speak("Welcome to Bruce Advanced Mode. How can I assist you?")
    while True:
        command = take_advanced_command()

        if "sync" in command:
            sync_basic_advanced()
        elif "chat" in command or "ask" in command:
            speak("What do you want to ask ChatGPT?")
            prompt = take_advanced_command()
            chat_with_gpt(prompt)
        elif "exit" in command or "quit" in command:
            speak("Exiting Advanced Mode.")
            break
        else:
            speak("Sorry, I didn't understand that. Can you repeat?")

if __name__ == "__main__":
    advanced_mode()
