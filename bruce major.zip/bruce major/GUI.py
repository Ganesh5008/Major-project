import tkinter as tk
from tkinter import scrolledtext
import threading
from basic import take_command, set_reminder, check_reminders, add_task, show_tasks, clear_tasks, get_weather, save_note, open_notepad, control_media, send_email, take_screenshot  # Assuming you already have these functions in basic.py
from advanced import take_advanced_command, sync_basic_advanced, chat_with_gpt
from datetime import datetime

class BruceAssistantApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Bruce Assistant")
        
        # Title and Secondary Heading
        self.header_label = tk.Label(self.root, text="BRUCE - Your Personal Assistant", font=("Arial", 24, "bold"))
        self.header_label.pack(pady=10)
        
        self.sub_header_label = tk.Label(self.root, text="Welcome Jainath", font=("Arial", 16))
        self.sub_header_label.pack(pady=5)

        # Mode selection buttons
        self.mode = None  # Mode can be "basic" or "advanced"
        self.basic_button = tk.Button(self.root, text="Basic Mode", width=20, command=self.start_basic_mode)
        self.basic_button.pack(padx=10, pady=5)

        self.advanced_button = tk.Button(self.root, text="Advanced Mode", width=20, command=self.start_advanced_mode)
        self.advanced_button.pack(padx=10, pady=5)

        # Conversation display
        self.conversation_display = scrolledtext.ScrolledText(self.root, width=80, height=20)
        self.conversation_display.pack(padx=10, pady=10)
        
        # Speak button (to give input to the assistant)
        self.speak_button = tk.Button(self.root, text="Speak", width=20, command=self.listen_and_process)
        self.speak_button.pack(padx=10, pady=5)

        # Exit button
        self.exit_button = tk.Button(self.root, text="Exit", width=20, command=self.exit_app)
        self.exit_button.pack(padx=10, pady=5)

    def start_basic_mode(self):
        self.mode = "basic"
        self.conversation_display.insert(tk.END, "Basic Mode selected. Please give a command...\n")

    def start_advanced_mode(self):
        self.mode = "advanced"
        self.conversation_display.insert(tk.END, "Advanced Mode selected. Please give a command...\n")

    def listen_and_process(self):
        if self.mode is None:
            self.conversation_display.insert(tk.END, "Please select a mode first.\n")
            return

        if self.mode == "basic":
            command = take_command()  # Listen for basic mode command
            self.process_speech_input(command)
        elif self.mode == "advanced":
            command = take_advanced_command()  # Listen for advanced mode command
            self.process_speech_input(command)

    def process_speech_input(self, command):
        if command:  # Only proceed if there is a valid command
            self.conversation_display.insert(tk.END, f"You said: {command}\n")
            if self.mode == "basic":
                self.basic_mode_processing(command)
            elif self.mode == "advanced":
                self.advanced_mode_processing(command)
        else:
            self.conversation_display.insert(tk.END, "No command detected. Please try again.\n")

    def basic_mode_processing(self, command):
        # Handle basic mode commands here
        if "open file" in command:
            self.conversation_display.insert(tk.END, "Opening file...\n")
            # Add actual logic here if needed
            self.speak("Opening file...")
        elif "screenshot" in command:
            self.conversation_display.insert(tk.END, "Taking a screenshot...\n")
            take_screenshot()  # Call the screenshot function from basic.py
            self.speak("Screenshot taken.")
        elif "add reminder" in command:
            reminder = set_reminder()  # Assuming the reminder function returns the reminder text
            self.conversation_display.insert(tk.END, f"Reminder added: {reminder}\n")
            self.speak(f"Reminder added: {reminder}")
        elif "send email" in command:
            self.conversation_display.insert(tk.END, "Initiating the send email process...\n")
            send_email()  # Call the send_email function from basic.py
            self.speak("Initiating the send email process...")
        elif "check reminders" in command:
            check_reminders()
            self.conversation_display.insert(tk.END, "Checked reminders.\n")
            self.speak("Checked reminders.")
        elif "add task" in command:
            add_task()
            self.conversation_display.insert(tk.END, "Task added.\n")
            self.speak("Task added.")
        elif "show tasks" in command:
            show_tasks()
            self.conversation_display.insert(tk.END, "Showing tasks.\n")
            self.speak("Showing tasks.")
        elif "clear task" in command:
            clear_tasks()
            self.conversation_display.insert(tk.END, "Cleared tasks.\n")
            self.speak("Cleared tasks.")
        elif "get weather" in command:
            get_weather()
            self.conversation_display.insert(tk.END, "Getting weather update...\n")
            self.speak("Getting weather update.")
        elif "save note" in command:
            save_note()
            self.conversation_display.insert(tk.END, "Note saved.\n")
            self.speak("Note saved.")
        elif "notepad" in command:
            open_notepad()
            self.conversation_display.insert(tk.END, "Notepad opened.\n")
            self.speak("Notepad opened.")
        elif "play song" in command or "stop" in command or "next" in command or "previous" in command or "volume up" in command or "volume down" in command or "pause" in command:
            control_media(command)
            self.conversation_display.insert(tk.END, f"Executing media command: {command}\n")
            self.speak(f"Executing media command: {command}")
        elif "what is the time" in command:
            current_time = datetime.now().strftime("%H:%M:%S")
            self.conversation_display.insert(tk.END, f"The current time is: {current_time}\n")
            self.speak(f"The current time is: {current_time}")
        elif "exit" in command:
            self.conversation_display.insert(tk.END, "Exiting Basic Mode...\n")
            self.speak("Exiting Basic Mode...")
            self.mode = None  # Reset mode
        else:
            self.conversation_display.insert(tk.END, f"Unknown command in Basic Mode: {command}\n")
            self.speak(f"Unknown command: {command}")

    def advanced_mode_processing(self, command):
        # Handle advanced mode commands here
        if "sync" in command:
            sync_basic_advanced()
            self.conversation_display.insert(tk.END, "Synced tasks, reminders, and notes.\n")
            self.speak("Synced tasks, reminders, and notes.")
        elif "chat" in command or "ask" in command:
            self.conversation_display.insert(tk.END, "Chatting with GPT...\n")
            self.speak("Chatting with GPT...")
            prompt = command.replace("chat", "").replace("ask", "").strip()  # Extract prompt
            chat_with_gpt(prompt)
        elif "exit" in command:
            self.conversation_display.insert(tk.END, "Exiting Advanced Mode...\n")
            self.speak("Exiting Advanced Mode...")
            self.mode = None  # Reset mode
        else:
            self.conversation_display.insert(tk.END, f"Unknown command in Advanced Mode: {command}\n")
            self.speak(f"Unknown command in Advanced Mode: {command}")

    def exit_app(self):
        self.root.quit()  # Quit the application

    def speak(self, text):
        # Assuming you have a speak function in basic.py or use pyttsx3 to speak the text
        import pyttsx3
        engine = pyttsx3.init()
        engine.say(text)
        engine.runAndWait()

# Run the application
if __name__ == "__main__": 
    root = tk.Tk()
    app = BruceAssistantApp(root)
    root.mainloop()
